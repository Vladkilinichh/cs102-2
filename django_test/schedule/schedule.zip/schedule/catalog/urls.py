from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name='index'),
    path('admin', views.admin, name='admin'),
    path('get_subject', views.get_subject, name='get_subject'),
    path('add_subject', views.add_subject, name='add_subject'),
    path('open_file', views.open_file, name= 'open_file'),
]