from django.db import models
from django.urls import reverse
import uuid
from django.utils import timezone


#dodelat
class MyModel(models.Model):
    
    my_field_name = models.CharField(max_length=20, help_text="Enter field documentation")

    class Meta:
        ordering = ["-my_field_name"]

    def get_absolute_url(self):
        return reverse('model-detail-view', args=[str(self.id)])
    
    def __str__(self):
        return self.field_name

class Direction(models.Model):
    
    LOAN_DIRECTION = (
        ( 'M', 'Moscow'),
        ( 'P', 'Paris'),
    )
    Direction = models.CharField(max_length=1, choices=LOAN_DIRECTION, blank=True, default='M', help_text='Choose your direction')
    
    def __str__(self):
        return self.Direction

class Information(models.Model):
    flight = models.CharField(max_length=200)
    summary = models.TextField(max_length=1000, help_text="Enter a brief description of the flight")
    #isbn = models.CharField('ISBN',max_length=13, help_text='13 Character <a href="https://www.isbn-international.org/content/what-isbn">ISBN number</a>')
    Direction = models.ManyToManyField(Direction, help_text="Select a genre for this book")

    def __str__(self):
        return self.flight

    def get_absolute_url(self):
        return reverse('flight-detail', args=[str(self.id)])


class Res(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, help_text="Unique ID for this flight")
    Information = models.ForeignKey('Information', on_delete=models.SET_NULL, null=True) 
    due_back = models.DateField(null=True, blank=True)

    LOAN_STATUS = (
        ('m', 'Maintenance'),
        ('o', 'On loan'),
        ('a', 'Available'),
        ('r', 'Reserved'),
    )
    status = models.CharField(max_length=1, choices=LOAN_STATUS, blank=True, default='m', help_text='Flight availability')

    def __str__(self):
        return '%s (%s)' % (self.id)


class Post(models.Model):
    author = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    text = models.TextField()
    create_date = models.DateTimeField(
        default=timezone.now)
    published_date = models.DateTimeField(
        blank=True, null=True)
    def publish(self):
        self.published_date = timezone.now()
        self.save()
    def __str__(self):
        return self.title

