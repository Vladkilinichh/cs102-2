# -*- coding: utf-8 -*-
import sys
import string
import os
import json
from django.shortcuts import render, HttpResponse
from .models import Post
from django.utils import timezone


def open_file(name):
    file = r"database.json".format(name)
    path = os.getcwd() + file
    data = open("database.json")

    return data

def write_in_file(name, text):
    file = r"database.json".format(name)
    path = os.getcwd() + file
    data = open(database.json)

    return data


def index(request):
    database = open('database.json')
    db = database.read()
    database.close()
    db_json = json.loads(db)
    return render(request, 'index.html', {'a': db_json})

def admin(request):
    database = open('database.json')
    db = database.read()
    database.close()
    db_json = json.loads(db)
    return render(request, 'admin.html', {'a': db_json})




def add_subject(request):
    orgs = open_file("database.json")
    for i in orgs:
        if i["name"] == request.POST.get("1"):
            subject = {"name" : request.POST.get("name"),
            "semestr" : request.POST.get("semestr"),
            "data" : request.POST.get("data"),
            "time" : request.POST.get("time")}
            i["subject"].append(subject)
            write_in_file("database.json", str(orgs).replace("\'", "\""))
            return render(request, "admin.html", {'orgs': orgs})

    return render(request, "index.html", {'orgs': orgs})


def get_subject(request):
    orgs = open_file("database.json")
    for i in orgs:
        if i == request.POST.get("org"):
            return render(request, "index.html", {'org': i})

    return render(request, "index.html", {'orgs': orgs})
 



