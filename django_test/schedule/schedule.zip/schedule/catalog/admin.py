from django.contrib import admin
#from .models import Information, Direction, Res

#admin.site.register(Information) / admin.site.register(Direction) / admin.site.register(Res)
